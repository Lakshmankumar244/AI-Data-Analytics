import { useAppState, useActions } from "../../state/AppContext";
import "./FilterBar.css";

const RANGE_LABELS = { "30d": "Last 30 days", "90d": "Last 90 days", "180d": "Last 6 months", all: "All time" };
const CLOCK_LABELS = { created: "Created date", modified: "Modified date" };

export default function FilterBar() {
  const { connection, scan, scanConfig, filterModules } = useAppState();
  const { setFilter, showHome } = useActions();
  const reportClock = scan?.reportContext?.clock;
  const clockLabel = reportClock
    ? reportClock === "Created_Time" ? "Created date" : reportClock === "Modified_Time" ? "Modified date" : reportClock
    : CLOCK_LABELS[scanConfig.clock] ?? scanConfig.clock;
  const rangeLabel = scan?.reportContext
    ? `${scan.reportContext.fromUtc || "—"} – ${scan.reportContext.toUtc || "—"}`
    : RANGE_LABELS[scanConfig.range?.id] ?? "Custom range";
  const depthLabel = String(scan?.reportContext?.depth || scanConfig.depth || "quick")
    .replace(/^./, (letter) => letter.toUpperCase());
  const reportConnection = scan?.reportContext?.connection;
  const userLabel = reportConnection
    ? reportConnection.name || reportConnection.email
    : connection?.connectedUser?.name || connection?.connectedUser?.email;
  const organizationLabel = reportConnection
    ? reportConnection.organizationName || reportConnection.organizationId
    : connection?.organizationName || connection?.organizationId;
  const accountLabel = [organizationLabel, userLabel].filter(Boolean).join(" · ");
  const scannedModules = scan?.moduleFindings?.length
    ? scan.moduleFindings.map((module) => ({ apiName: module.apiName, label: module.label }))
    : (connection?.accessibleModules ?? []).filter((module) => scanConfig.modules.includes(module.apiName));
  const displayedModules = filterModules.length
    ? scannedModules.filter((module) => filterModules.includes(module.apiName))
    : scannedModules;

  function toggleModule(apiName) {
    const set = new Set(filterModules);
    set.has(apiName) ? set.delete(apiName) : set.add(apiName);
    setFilter({ filterModules: Array.from(set) });
  }

  return (
    <header className="filter-bar">
      <div className="filter-bar-main">
        <button type="button" className="filter-bar-back" onClick={showHome}>
          <span aria-hidden="true">←</span> Reports
        </button>
        <div className="filter-bar-title">
          <p className="eyebrow">Data health report</p>
          <h1>{displayedModules.map((module) => module.label).join(" + ") || "Analytics"}</h1>
        </div>
        <div className="filter-bar-meta">
          {accountLabel && <span className="filter-bar-account" title={accountLabel}>{accountLabel}</span>}
          <span className="filter-bar-meta-item">{clockLabel}</span>
          <span className="filter-bar-meta-item">{rangeLabel}</span>
          <span className="filter-bar-depth">{depthLabel} scan</span>
        </div>
      </div>
      <div className="filter-bar-chips" aria-label="Filter report modules">
        <span className="filter-bar-filter-label">Modules</span>
        {scannedModules.map((module) => {
          const isActive = filterModules.length === 0 || filterModules.includes(module.apiName);
          return (
            <button key={module.apiName} type="button" className="chip" aria-pressed={isActive}
              onClick={() => toggleModule(module.apiName)}>
              {module.label}
            </button>
          );
        })}
      </div>
    </header>
  );
}
