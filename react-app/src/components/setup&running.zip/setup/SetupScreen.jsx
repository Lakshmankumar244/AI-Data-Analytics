import { useEffect, useState } from "react";
import { useAppState, useActions, useAppDispatch } from "../../state/AppContext";
import * as api from "../../data/client";
import AccessibleModulesList from "./AccessibleModulesList";
import DepthSelector from "./DepthSelector";
import ClockToggle from "./ClockToggle";
import DateRangePicker from "./DateRangePicker";
import CostEstimate from "./CostEstimate";
import LoadingState from "../shared/LoadingState";
import "./SetupScreen.css";

export default function SetupScreen() {
  const { connection, scanConfig } = useAppState();
  const { setScanConfig } = useActions();
  const dispatch = useAppDispatch();
  const [estimate, setEstimate] = useState(null);
  const [estimating, setEstimating] = useState(false);
  const [starting, setStarting] = useState(false);

  // Default module selection to everything accessible, once the connection loads.
  useEffect(() => {
    if (connection && scanConfig.modules.length === 0) {
      setScanConfig({ modules: connection.accessibleModules.map((m) => m.apiName) });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connection]);

  useEffect(() => {
    if (!scanConfig.modules.length) {
      setEstimate(null);
      return;
    }
    let cancelled = false;
    setEstimating(true);
    api.estimateScan(scanConfig).then((result) => {
      if (!cancelled) {
        setEstimate(result);
        setEstimating(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [scanConfig.modules, scanConfig.depth]);

  if (!connection) {
    return <LoadingState label="Loading your connection" />;
  }

  function toggleModule(apiName) {
    const set = new Set(scanConfig.modules);
    set.has(apiName) ? set.delete(apiName) : set.add(apiName);
    setScanConfig({ modules: Array.from(set) });
  }

  async function handleStart() {
    setStarting(true);
    const scanId = `scan_${Date.now()}`;
    // Switch to the running screen immediately so progress renders live,
    // rather than waiting for the whole simulated scan to finish first.
    dispatch({ type: "scanStarted", scanId });

    await api.startScan(scanConfig, (progress) => {
      dispatch({ type: "progressUpdate", module: progress.module, progress });
      if (progress.complete) {
        dispatch({ type: "moduleComplete", module: progress.module });
      }
    });

    const scan = await api.getScorecard(scanId);
    dispatch({ type: "scanComplete", scan });
  }

  return (
    <div className="setup-screen">
      <header className="setup-header">
        <h1>Check your data health</h1>
        <p className="setup-subhead">
          Connected as <strong>{connection.connectedUser.name}</strong>. This scans
          only what your account can see in Zoho CRM.
        </p>
      </header>

      <div className="setup-grid">
        <section className="panel">
          <AccessibleModulesList
            modules={connection.accessibleModules}
            selected={scanConfig.modules}
            onToggle={toggleModule}
          />
        </section>

        <section className="panel">
          <DepthSelector
            value={scanConfig.depth}
            onChange={(depth) => setScanConfig({ depth })}
          />
        </section>

        <section className="panel setup-panel-row">
          <ClockToggle value={scanConfig.clock} onChange={(clock) => setScanConfig({ clock })} />
          <DateRangePicker value={scanConfig.range} onChange={(range) => setScanConfig({ range })} />
        </section>

        <section className="panel">
          <CostEstimate estimate={estimate} loading={estimating} />
        </section>
      </div>

      <div className="setup-actions">
        <button
          type="button"
          className="btn btn-primary"
          disabled={!scanConfig.modules.length || starting}
          onClick={handleStart}
        >
          {starting ? "Starting\u2026" : "Run scan"}
        </button>
      </div>
    </div>
  );
}
