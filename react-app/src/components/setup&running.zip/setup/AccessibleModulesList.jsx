import { formatNumber } from "../../utils/format";

export default function AccessibleModulesList({ modules, selected, onToggle }) {
  return (
    <div>
      <p className="eyebrow">Accessible to your account</p>
      <p className="setup-hint">
        These are the modules and record counts visible under your own Zoho login -
        not necessarily everything in the org. A small count here usually means your
        profile's visibility, not an empty module.
      </p>
      <ul className="module-list" role="group" aria-label="Modules to include in the scan">
        {modules.map((m) => {
          const checked = selected.includes(m.apiName);
          return (
            <li key={m.apiName} className="module-row">
              <label>
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => onToggle(m.apiName)}
                />
                <span className="module-row-label">{m.label}</span>
              </label>
              <span className="module-row-count mono">{formatNumber(m.recordCount)} records</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
