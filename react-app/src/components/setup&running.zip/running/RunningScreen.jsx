import { useAppState } from "../../state/AppContext";
import ModuleProgressList from "./ModuleProgressList";
import "./RunningScreen.css";

export default function RunningScreen() {
  const { connection, scanConfig, progress, completedModules } = useAppState();

  const scopedModules = connection.accessibleModules.filter((m) =>
    scanConfig.modules.includes(m.apiName)
  );
  const allDone = completedModules.length === scopedModules.length && scopedModules.length > 0;

  return (
    <div className="running-screen">
      <header className="running-header">
        <p className="eyebrow">{allDone ? "Wrapping up" : "Scanning"}</p>
        <h1>{allDone ? "Putting your report together\u2026" : "Reading your records\u2026"}</h1>
        <p className="running-subhead">
          Read-only the whole way through. Nothing in your CRM is being changed.
        </p>
      </header>

      <div className="panel">
        <ModuleProgressList
          modules={scopedModules}
          progress={progress}
          completed={completedModules}
        />
      </div>
    </div>
  );
}
