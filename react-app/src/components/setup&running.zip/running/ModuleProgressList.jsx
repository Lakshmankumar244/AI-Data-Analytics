import { formatNumber } from "../../utils/format";

const PHASE_LABEL = {
  extracting: "Extracting",
  classifying: "Classifying",
  done: "Done",
};

export default function ModuleProgressList({ modules, progress, completed }) {
  return (
    <ul className="progress-list">
      {modules.map((mod) => {
        const p = progress[mod.apiName];
        const isDone = completed.includes(mod.apiName);
        const pct = p?.estimatedTotal ? Math.min(100, Math.round((p.scanned / p.estimatedTotal) * 100)) : 0;

        return (
          <li key={mod.apiName} className="progress-row">
            <div className="progress-row-top">
              <span className="progress-row-name">{mod.label}</span>
              <span className="progress-row-phase eyebrow">
                {isDone ? "Done" : p ? PHASE_LABEL[p.phase] ?? "Waiting" : "Queued"}
              </span>
            </div>
            <div className="progress-track">
              <div
                className={`progress-fill ${isDone ? "progress-fill-done" : ""}`}
                style={{ width: `${isDone ? 100 : pct}%` }}
              />
            </div>
            <div className="progress-row-count mono">
              {formatNumber(p?.scanned ?? 0)} / {formatNumber(mod.recordCount)}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
