import ScoreBar from "../../shared/ScoreBar";
import { DOMAIN_LABELS } from "../../../utils/bands";
import "./DomainScoreBars.css";

export default function DomainScoreBars({ domainScores, unmeasuredDomains = [] }) {
  const reasonFor = (domainId) =>
    unmeasuredDomains.find((u) => u.domain === domainId)?.reason;

  return (
    <div className="domain-score-bars">
      {domainScores.map((d) => (
        <ScoreBar
          key={d.domain}
          label={DOMAIN_LABELS[d.domain] ?? d.domain}
          score={d.score}
          applicable={d.applicable}
          reason={d.applicable ? undefined : reasonFor(d.domain)}
        />
      ))}
    </div>
  );
}
