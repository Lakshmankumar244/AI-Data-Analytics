import { useAppState, useActions } from "../../../state/AppContext";
import ScoreGauge from "../../shared/ScoreGauge";
import StateBreakdown from "../../shared/StateBreakdown";
import DomainScoreBars from "./DomainScoreBars";
import MoversList from "./MoversList";
import { formatNumber } from "../../../utils/format";
import "./OverviewTab.css";

export default function OverviewTab() {
  const { scan, focusState } = useAppState();
  const { setFilter } = useActions();

  if (!scan) return null;

  const {
    overallScore,
    priorScore,
    measuredPoints,
    possiblePoints,
    unmeasuredDomains,
    recordsInScope,
    stateBreakdown,
    domainScores,
    movers,
  } = scan;

  return (
    <div className="overview-tab">
      <section className="panel overview-score-panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Your data health</p>
            <h1>{formatNumber(recordsInScope)} records checked</h1>
          </div>
        </div>
        <ScoreGauge
          score={overallScore}
          priorScore={priorScore}
          measuredPoints={measuredPoints}
          possiblePoints={possiblePoints}
          unmeasuredDomains={unmeasuredDomains}
        />
      </section>

      <section className="panel">
        <div className="panel-header">
          <p className="eyebrow">Record states</p>
          {focusState && (
            <button
              type="button"
              className="overview-clear-focus"
              onClick={() => setFilter({ focusState: null })}
            >
              Clear focus
            </button>
          )}
        </div>
        <StateBreakdown
          breakdown={stateBreakdown}
          focusState={focusState}
          onFocus={(id) => setFilter({ focusState: id })}
        />
      </section>

      <div className="overview-grid">
        <section className="panel">
          <div className="panel-header">
            <p className="eyebrow">Domain scores</p>
          </div>
          <DomainScoreBars domainScores={domainScores} unmeasuredDomains={unmeasuredDomains} />
        </section>

        <section className="panel">
          <div className="panel-header">
            <p className="eyebrow">Biggest changes</p>
          </div>
          <MoversList movers={movers} />
        </section>
      </div>
    </div>
  );
}
