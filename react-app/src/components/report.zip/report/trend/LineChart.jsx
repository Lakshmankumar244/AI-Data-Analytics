import "./LineChart.css";

const WIDTH = 720;
const HEIGHT = 220;
const PAD = { top: 16, right: 16, bottom: 28, left: 32 };

/**
 * Deliberately hand-built rather than pulling in a charting library - the
 * project has zero runtime dependencies beyond react/react-dom, and one
 * line series doesn't need one. Score is always 0-100, so the y-axis is
 * fixed rather than computed from the data.
 */
export default function LineChart({ series, averageScore }) {
  const innerW = WIDTH - PAD.left - PAD.right;
  const innerH = HEIGHT - PAD.top - PAD.bottom;

  const x = (i) => PAD.left + (series.length <= 1 ? 0 : (i / (series.length - 1)) * innerW);
  const y = (score) => PAD.top + innerH * (1 - score / 100);

  const path = series.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(p.score)}`).join(" ");
  const gridLines = [0, 25, 50, 75, 100];

  return (
    <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} className="line-chart" role="img" aria-label="Score over time">
      {gridLines.map((g) => (
        <g key={g}>
          <line x1={PAD.left} x2={WIDTH - PAD.right} y1={y(g)} y2={y(g)} className="line-chart-grid" />
          <text x={PAD.left - 8} y={y(g) + 4} className="line-chart-axis-label mono" textAnchor="end">
            {g}
          </text>
        </g>
      ))}

      {typeof averageScore === "number" && (
        <line
          x1={PAD.left}
          x2={WIDTH - PAD.right}
          y1={y(averageScore)}
          y2={y(averageScore)}
          className="line-chart-average"
        />
      )}

      <path d={path} className="line-chart-line" fill="none" />

      {series.map((p, i) => (
        <circle key={p.period} cx={x(i)} cy={y(p.score)} r="3.5" className="line-chart-point" />
      ))}

      {series.map((p, i) => (
        <text key={p.period} x={x(i)} y={HEIGHT - 8} className="line-chart-axis-label mono" textAnchor="middle">
          {p.period}
        </text>
      ))}
    </svg>
  );
}
