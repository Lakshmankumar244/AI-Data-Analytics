import { useEffect, useState } from "react";
import { useAppState } from "../../../state/AppContext";
import * as api from "../../../data/client";
import LoadingState from "../../shared/LoadingState";
import LineChart from "./LineChart";
import { formatDelta } from "../../../utils/format";
import "./TrendTab.css";

export default function TrendTab() {
  const { scanId, scanConfig } = useAppState();
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setData(null);
    api.getTrend(scanId, "month", scanConfig.clock).then((res) => {
      if (!cancelled) setData(res);
    });
    return () => {
      cancelled = true;
    };
  }, [scanId, scanConfig.clock]);

  if (!data || data.series.length === 0) return <LoadingState label="Loading trend" />;

  const { series } = data;
  const average = series.reduce((sum, p) => sum + p.score, 0) / series.length;
  const first = series[0];
  const last = series[series.length - 1];
  const delta = last.score - first.score;

  return (
    <div className="trend-tab">
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Score over time</p>
            <h1>{first.period} → {last.period}</h1>
          </div>
        </div>

        <LineChart series={series} averageScore={average} />

        <p className="trend-summary">
          <span className="mono">{first.score}</span> in {first.period} to{" "}
          <span className="mono">{last.score}</span> in {last.period}
          {" "}(<span className={delta >= 0 ? "trend-up" : "trend-down"}>{formatDelta(delta)}</span>) ·
          period average <span className="mono">{average.toFixed(1)}</span>
        </p>
      </section>
    </div>
  );
}
