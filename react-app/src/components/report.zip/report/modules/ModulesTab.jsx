import { useEffect, useState } from "react";
import { useAppState } from "../../../state/AppContext";
import * as api from "../../../data/client";
import { DOMAIN_LABELS } from "../../../utils/bands";
import LoadingState from "../../shared/LoadingState";
import ModuleMatrix from "./ModuleMatrix";
import "./ModulesTab.css";

const DOMAIN_ORDER = [
  "completeness", "duplication", "validity", "plausibility",
  "freshness", "integrity", "config", "pii", "automation",
];

export default function ModulesTab() {
  const { scanId, connection, filterModules, scanConfig } = useAppState();
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setData(null);
    api.getModuleMatrix(scanId, { modules: filterModules }).then((res) => {
      if (!cancelled) setData(res);
    });
    return () => {
      cancelled = true;
    };
  }, [scanId, filterModules]);

  if (!data) return <LoadingState label="Loading module matrix" />;

  const minObservations = scanConfig.rules.matrixMinObservations;
  const recordCounts = Object.fromEntries(
    connection.accessibleModules.map((m) => [m.apiName, m.recordCount])
  );

  const visibleModules = data.modules.filter(
    (m) => filterModules.length === 0 || filterModules.includes(m.apiName)
  );

  return (
    <div className="modules-tab">
      <section className="panel modules-panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Modules</p>
            <h1>Scores by module and domain</h1>
          </div>
          <p className="modules-floor-note">
            Cells from fewer than <span className="mono">{minObservations}</span> eligible
            records show as N/A, not a score — too few records to be a reliable read.
          </p>
        </div>
        <ModuleMatrix
          modules={visibleModules}
          domainOrder={DOMAIN_ORDER}
          domainLabels={DOMAIN_LABELS}
          recordCounts={recordCounts}
          minObservations={minObservations}
        />
      </section>
    </div>
  );
}
