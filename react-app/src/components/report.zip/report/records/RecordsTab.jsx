import { useEffect, useState } from "react";
import { useAppState, useActions } from "../../../state/AppContext";
import * as api from "../../../data/client";
import { RECORD_STATES, stateMeta } from "../../../utils/bands";
import { formatNumber } from "../../../utils/format";
import Band from "../../shared/Band";
import LoadingState from "../../shared/LoadingState";
import "./RecordsTab.css";

function formatDate(iso) {
  return new Date(iso).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" });
}

export default function RecordsTab() {
  const { scanId, focusState, filterModules } = useAppState();
  const { setFilter } = useActions();
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);

  // Any filter change resets to page 1 - a stale page number past the end
  // of a newly-filtered result set would just render an empty table.
  useEffect(() => {
    setPage(1);
  }, [focusState, filterModules]);

  useEffect(() => {
    let cancelled = false;
    setData(null);
    const filters = { states: focusState ? [focusState] : [], modules: filterModules };
    api.getRecords(scanId, filters, page).then((res) => {
      if (!cancelled) setData(res);
    });
    return () => {
      cancelled = true;
    };
  }, [scanId, focusState, filterModules, page]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="records-tab">
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Records</p>
            <h1>Flagged records</h1>
          </div>
        </div>

        <div className="records-state-filter" role="group" aria-label="Filter by state">
          <button
            type="button"
            className={`chip${!focusState ? " chip-active" : ""}`}
            aria-pressed={!focusState}
            onClick={() => setFilter({ focusState: null })}
          >
            All
          </button>
          {RECORD_STATES.filter((s) => s.id !== "proper").map((s) => (
            <button
              key={s.id}
              type="button"
              className={`chip${focusState === s.id ? " chip-active" : ""}`}
              aria-pressed={focusState === s.id}
              onClick={() => setFilter({ focusState: focusState === s.id ? null : s.id })}
            >
              {s.label}
            </button>
          ))}
        </div>

        {!data ? (
          <LoadingState label="Loading records" />
        ) : (
          <>
            <div className="records-table-wrap">
              <table className="records-table">
                <thead>
                  <tr>
                    <th>Record</th>
                    <th>Module</th>
                    <th>State</th>
                    <th>What's wrong</th>
                    <th>Created by</th>
                    <th>Created</th>
                  </tr>
                </thead>
                <tbody>
                  {data.records.length === 0 && (
                    <tr>
                      <td colSpan={6} className="records-empty">
                        No records match this filter.
                      </td>
                    </tr>
                  )}
                  {data.records.map((r) => (
                    <tr key={r.id}>
                      <td className="mono records-id">{r.id}</td>
                      <td>{r.module}</td>
                      <td>
                        <Band band={stateMeta(r.state)} size="sm" />
                      </td>
                      <td>{r.reason}</td>
                      <td>{r.createdBy}</td>
                      <td className="mono">{formatDate(r.createdTime)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="records-pagination">
              <span className="records-pagination-count">
                {formatNumber(data.total)} record{data.total === 1 ? "" : "s"}
              </span>
              <div className="records-pagination-controls">
                <button
                  type="button"
                  className="btn btn-secondary"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  Previous
                </button>
                <span className="mono records-pagination-page">
                  {page} / {totalPages}
                </span>
                <button
                  type="button"
                  className="btn btn-secondary"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </button>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
