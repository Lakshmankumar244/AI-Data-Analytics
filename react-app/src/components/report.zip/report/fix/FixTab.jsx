import { useEffect, useState } from "react";
import { useAppState } from "../../../state/AppContext";
import * as api from "../../../data/client";
import { formatNumber } from "../../../utils/format";
import LoadingState from "../../shared/LoadingState";
import "./FixTab.css";

/**
 * This app connects read-only (decisions-log.md, B2 - no write scope was
 * ever requested), so nothing here can actually merge, backfill, or correct
 * a record. This is a trackable plan, not a button that changes your CRM.
 * Checking an item just marks it "planned" locally - it's cleared if you
 * leave the tab, since there's nowhere to persist it yet.
 *
 * The "projected score" is a simple sum of each checked action's pointGain,
 * capped at 100. That's a real simplification, not a modeled recompute -
 * two actions that touch overlapping records wouldn't actually be additive
 * in a real scoring pass. Good enough for "roughly how much this is worth,"
 * not precise enough to promise an exact number.
 */
export default function FixTab() {
  const { scanId, scan } = useAppState();
  const [plan, setPlan] = useState(null);
  const [selected, setSelected] = useState(() => new Set());

  useEffect(() => {
    api.getFixPlan(scanId).then(setPlan);
  }, [scanId]);

  if (!plan) return <LoadingState label="Loading remediation plan" />;

  function toggle(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  const selectedActions = plan.actions.filter((a) => selected.has(a.id));
  const selectedRecords = selectedActions.reduce((sum, a) => sum + a.recordCount, 0);
  const gain = selectedActions.reduce((sum, a) => sum + (a.pointGain ?? 0), 0);
  const currentScore = scan?.overallScore ?? 0;
  const projectedScore = Math.min(100, Math.round((currentScore + gain) * 10) / 10);

  return (
    <div className="fix-tab">
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Remediation plan</p>
            <h1>What to fix, and who needs to do it</h1>
          </div>
        </div>

        <p className="fix-readonly-note">
          This connection is read-only, so nothing here writes back to your CRM
          automatically. Check items to build a plan you can hand off or work through
          manually.
        </p>

        <ul className="fix-action-list">
          {plan.actions.map((a) => (
            <li key={a.id} className="fix-action">
              <label className="fix-action-check">
                <input
                  type="checkbox"
                  checked={selected.has(a.id)}
                  onChange={() => toggle(a.id)}
                />
              </label>
              <div className="fix-action-body">
                <div className="fix-action-top">
                  <h3>{a.title}</h3>
                  {a.pointGain !== null ? (
                    <span className="fix-action-gain">+{a.pointGain} pts</span>
                  ) : (
                    <span className="fix-action-gain fix-action-gain-review">review only</span>
                  )}
                </div>
                <p className="fix-action-desc">{a.description}</p>
                <p className="fix-action-meta">
                  <span className="mono">{formatNumber(a.recordCount)}</span> records ·{" "}
                  {a.modules.join(", ")}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <div className="fix-summary-bar">
        <div className="fix-summary-scores">
          <span className="mono fix-summary-current">{currentScore}</span>
          <span className="fix-summary-arrow" aria-hidden="true">→</span>
          <span className="mono fix-summary-projected">{projectedScore}</span>
        </div>
        <span className="fix-summary-detail">
          {selected.size} action{selected.size === 1 ? "" : "s"} selected ·{" "}
          {formatNumber(selectedRecords)} records
        </span>
      </div>
    </div>
  );
}
